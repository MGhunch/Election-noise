# Source

**Reads:** party websites · **Produces:** raw sourced material for Sort and Summarise

Find what each party is actually campaigning on, in the party's own words, and file it under the right heading. No scoring happens here.

Sort and Summarise both read what this stage produces. They don't run one after the other — they run off the same sourced material, which is why nothing either of them writes can contain a fact this stage didn't capture.

This briefing was given in conversation across six party sweeps rather than written down first. What follows is the briefing as it settled — reconstructed from its own output.

---

## Where to start

Start from the party's own curated policy hub — the page the party itself uses to say "these are our policies." Not the news feed, not a search engine, not last election's platform.

Every party publishes a different shape, and the shape is itself worth recording:

- **Hub of hubs** — a policy index whose entries are themselves index pages with their own sub-policies. Each sub-page gets checked.
- **Flat list** — a clean set of named policies, one page each.
- **Numbered plan** — an explicit list of election commitments, sitting inside a site otherwise built on record.
- **Filterable grid** — topic cards of wildly uneven depth, where one card unpacks into six scoreable policies and the next repeats its own preview text.

Where a hub entry has its own page, use the page. One record per policy, at the resolution the party publishes it — not one record standing in for three separate commitments with three separate dates.

## Where the citation comes from

News feeds aren't swept — nobody trawls a chronological archive looking for policy. But where a policy has been reported, the report is the citation, and the party page moves to `party_link`. Roughly half the records carry one.

The standard is national newsrooms with their own reporting: **RNZ**, **TVNZ**, **NZ Herald**, **The Post**, **Stuff**, **Newsroom**, **BusinessDesk**, **The Spinoff**. RNZ accounts for most of it. Scoop and party press releases carried by aggregators are the party's own words on someone else's paper — useful, but they don't lift a record's status.

A record cited to reporting is marked verified. A record cited only to the party's own site isn't. That isn't a judgement about the policy — an unverified policy is just as real. It records whether anyone outside the party has written it down, which is a fact worth publishing about the campaign as well as the record.

## What to capture

For each candidate:

- **party**
- **source** — the URL actually fetched
- **raw text** — the party's own words, quoted, long enough to carry the mechanism. Numbers, dates, thresholds and named legislation verbatim.

Quote rather than paraphrase. The next stages can only describe what they can read, and a summary of a summary loses the numbers.

## What to exclude, and say so

Exclusions get recorded, not made silently. A reader should be able to see what was left out and disagree with it.

- **News and press-release feeds** — chronological archives mixing policy with candidate announcements and commentary. Not swept.
- **Achievements pages** — "what we've delivered." A governing party's site can be almost entirely this. That's a finding about the campaign, not a gap in the sweep.
- **Prior-cycle content** — previous election platforms, and pages whose own metadata dates them to an earlier campaign.
- **Standing policy libraries** — permanent platform maintained continuously rather than published as a campaign commitment.
- **Values and priorities pages** — framing with no mechanism, number or date attached.

## What to flag rather than fix

Sourcing doesn't correct, score or deduplicate. It flags, and the flag travels with the record:

- **Stale citation** — the policy is live this cycle but the link is to an earlier one.
- **Currency** — the policy has been overtaken by events rather than mis-cited.
- **Thin** — the page is a launcher, a placeholder, or ends "detailed policy at launch."
- **Unreachable** — the mechanism sits in a document that couldn't be fetched.
- **Off-hub** — an existing commitment the party no longer features on its own policy page.
- **Possible duplicate** — two records that may be one policy. Noted, not merged.

## What "checked" means

Say what was checked and what wasn't. A sweep that opened three cards out of seventeen says so. Completeness is uneven between parties, and the unevenness is worth publishing, because it shapes how much of each party's platform reaches the map.

## The first pass and the ones after it

The rules above describe a sweep from nothing: open the hub, work through it, report what's there. Anyone can run it that way, on any party, and get a usable set of candidates.

A repeat pass is a different job. It reads `data/policies.json` first, and reports only what isn't already in it.

- **Check every candidate against the existing records before writing it up.** Same policy, same mechanism, already captured — say so in a line and move on. The output of a recurring pass should be short, and usually is.
- **Say what was checked and found unchanged**, not just what's new. A hub with nothing new on it is a result, and without it there's no way to tell a quiet week from a pass that didn't happen.
- **Match on the policy, not the wording.** Parties re-announce, rename and re-launch. A costing that has grown, a date that has moved, a scheme with a new name — that's an existing record to update, not a new one to mint.

Two flags belong only to a repeat pass:

- **Moved** — the policy is still live but a number, date or threshold has changed since it was captured. Name the old value and the new one.
- **Withdrawn** — the policy has come off the party's hub since the last pass. Not the same as overtaken by events; the party has taken it down.

Neither is fixed here. Sourcing still only flags.

## Categories

Every record carries one conversation category, and optionally a second. This one is a human call. There's no prompt behind it — but there are rules, and they were built one disagreement at a time.

The nine conversations: **Cost of Living · Economy · Health · Housing · Education · Crime & Justice · Environment · Future & Infrastructure · Government & Democracy**

**Purpose, informed by mechanism.** Categorise by what the policy *is*, read honestly. A household energy scheme aimed at long-run generation is Future & Infrastructure, not Cost of Living, even though it lands on a power bill.

**Instruments, not destinations.** Score the tool, not where its money is pointed. A capital gains tax is a tax whatever it funds. Ring-fencing is a fact about the policy, not a change to its category.

**A second category is for genuine dual residence**, not for hedging. Most records don't need one.

## Output

One block per candidate — party, source, raw text — plus a short note on the site's shape, what was excluded, and what wasn't reached. No scores, no descriptions.

On a first pass, that's every candidate found. On a repeat pass it's only the ones that aren't already in the file, with a line on what was checked and found unchanged. Either way, nothing here is merged, corrected or scored — that's the next stage's job.
